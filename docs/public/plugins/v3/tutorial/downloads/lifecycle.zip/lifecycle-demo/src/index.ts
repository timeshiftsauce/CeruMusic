import { definePlugin } from '@shiqianjiang/ceru-plugin-sdk'

export default definePlugin({
  async onInstall(ctx) {
    if (await ctx.storage.get('firstVersion') === null) {
      await ctx.storage.set('firstVersion', ctx.plugin.version)
    }
  },
  async onUpdate(ctx, { from }) {
    await ctx.storage.set('lastUpgrade', { from, to: ctx.plugin.version })
  },
  async setup(ctx) {
    ctx.log.info('逻辑启动', {
      firstVersion: await ctx.storage.get('firstVersion'),
      lastUpgrade: await ctx.storage.get('lastUpgrade'),
    })
  },
  onEnable(ctx) {
    ctx.log.info('用户启用')
  },
  onThemeChange(ctx, theme) {
    ctx.log.info('深浅色变化', { theme })
  },
})