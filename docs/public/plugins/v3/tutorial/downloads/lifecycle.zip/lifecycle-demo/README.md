# lifecycle-demo

使用 Node.js 22.12 或更新版本，在本目录运行：

```sh
npm install
npm run build
npm run validate
```

在支持 v3 的澜音桌面打开普通插件管理，安装 dist/plugin.js 后手动启用。用普通安装验证首次安装和同 ID 更新。

分别首次安装、启用、切换主题、同 ID 升级；在插件日志中对照 firstVersion 和 lastUpgrade。
