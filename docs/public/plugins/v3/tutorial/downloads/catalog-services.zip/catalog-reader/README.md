# catalog-reader

使用 Node.js 22.12 或更新版本，在本目录运行：

```sh
npm install
npm run build
npm run validate
```

在支持 v3 的澜音桌面开发者模式加载 dist/plugin.js。验证后可用 npm run dev 监听源码变化。

运行 npx --no-install ceru-plugin test-services。两个场景通过后，在桌面启用消费方、授予服务权限并点击查询。
