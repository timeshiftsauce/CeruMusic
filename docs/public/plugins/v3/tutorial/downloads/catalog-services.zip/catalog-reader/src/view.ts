import { defineSurface } from '@shiqianjiang/ceru-plugin-sdk'

export default defineSurface(ctx => {
  const button = document.createElement('button')
  const output = document.createElement('output')
  button.textContent = '查歌曲'
  button.onclick = async () => {
    button.disabled = true
    try {
      const value = await ctx.invoke('lookup.song', { id: '1' })
      output.textContent = value && typeof value === 'object' && !Array.isArray(value)
        && typeof value.title === 'string' ? value.title : '未找到，请检查曲库插件是否已启用'
    } catch (error) {
      output.textContent = String(error)
    } finally {
      button.disabled = false
    }
  }
  ctx.root.replaceChildren(button, output)
  return () => { button.onclick = null; ctx.root.replaceChildren() }
})