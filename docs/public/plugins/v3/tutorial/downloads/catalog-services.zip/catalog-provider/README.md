# catalog-provider

使用 Node.js 22.12 或更新版本，在本目录运行：

```sh
npm install
npm run build
npm run validate
```

在支持 v3 的澜音桌面开发者模式加载 dist/plugin.js。验证后可用 npm run dev 监听源码变化。

先启用这个服务提供方，再打开 catalog-reader 工程。
