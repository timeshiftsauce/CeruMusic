import { defineSurface } from '@shiqianjiang/ceru-plugin-sdk'

export default defineSurface(ctx => {
  const button = document.createElement('button')
  const output = document.createElement('output')
  button.textContent = '导入并读取名称'
  button.onclick = async () => {
    button.disabled = true
    try {
      const info = await ctx.invoke('guest.try', null)
      output.textContent = info && typeof info === 'object' && !Array.isArray(info)
        && typeof info.name === 'string' ? info.name : '已取消'
    } catch (error) {
      output.textContent = String(error)
    } finally {
      button.disabled = false
    }
  }
  ctx.root.replaceChildren(button, output)
  return () => { button.onclick = null; ctx.root.replaceChildren() }
})