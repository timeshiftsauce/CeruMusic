import { defineGuestAdapter } from '@shiqianjiang/ceru-plugin-sdk'

export default defineGuestAdapter(ctx => {
  ctx.handle(async method => {
    if (method === 'info') return { name: ctx.scriptInfo.name }
    throw new Error('未知的 Guest 方法')
  })
  ctx.ready({ providers: [] })
})