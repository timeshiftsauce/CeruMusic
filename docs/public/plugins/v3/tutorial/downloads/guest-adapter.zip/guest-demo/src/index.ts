import { definePlugin } from '@shiqianjiang/ceru-plugin-sdk'
export default definePlugin(ctx => {
ctx.actions.register('guest.try', async (_input, operation) => {
  const item = await ctx.guests.import('example-script')
  if (!item) return null
  await ctx.guests.select(item.id)
  return ctx.guests.invoke(item.id, 'info', null, operation)
})
})
