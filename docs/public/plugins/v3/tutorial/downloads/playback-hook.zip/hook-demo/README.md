# hook-demo

使用 Node.js 22.12 或更新版本，在本目录运行：

```sh
npm install
npm run build
npm run validate
```

在支持 v3 的澜音桌面开发者模式加载 dist/plugin.js。验证后可用 npm run dev 监听源码变化。

运行 npm test。15 个场景应通过，包括歌名中间含标记时允许播放。
